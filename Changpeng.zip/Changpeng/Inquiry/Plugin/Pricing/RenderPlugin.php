<?php
/**
 * Class RenderPlugin
 *
 * PHP version 7 & 8
 *
 * @category Changpeng
 * @package  Changpeng_Inquiry
 * @author   Changpeng <magento@changpeng.com>
 * @license  https://hncpsm.com  Open Software License (OSL 3.0)
 * @link     https://hncpsm.com */
namespace Changpeng\Inquiry\Plugin\Pricing;

use Magento\Framework\Registry;
use Magento\Framework\View\Element\Template;


class RenderPlugin extends \Magento\Catalog\Pricing\Render
{
    /**
     * RenderPlugin constructor
     *
     * @param Template\Context $context
     * @param Registry $registry
     * @param \Changpeng\Inquiry\Helper\Data $helperData
     * @param array $data
     */
    public function __construct(
        Template\Context $context,
        Registry $registry,
        \Changpeng\Inquiry\Helper\Data $helperData,
        array $data = []
    ) {
        $this->helperData = $helperData;
        parent::__construct($context, $registry, $data);
    }

    /**
     * Hide price if disclose price is disabled
     *
     * @return string
     */
    protected function _toHtml()
    {
        $product = $this->getProduct();
        $disclosePrice = $this->helperData->getDisclosePrice($product->getId());

        if ($disclosePrice) {
            return parent::_toHtml();
        } else {
            return '';
        }
    }
}
