<?php
/**
 * Class Inquiry
 *
 * PHP version 7 & 8
 *
 * @category Changpeng
 * @package  Changpeng_Inquiry
 * @author   Changpeng <magento@changpeng.com>
 * @license  https://hncpsm.com  Open Software License (OSL 3.0)
 * @link     https://hncpsm.com */
namespace Changpeng\Inquiry\Model;

class Inquiry extends \Magento\Framework\Model\AbstractModel
{
    public const CACHE_TAG = 'changpeng_product_inquiry_post';

    /**
     * @var string
     */
    protected $_cacheTag = 'changpeng_product_inquiry_post';
    /**
     * @var string
     */
    protected $_eventPrefix = 'changpeng_product_inquiry_post';

    /**
     * Inquiry Constructor
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(\Changpeng\Inquiry\Model\ResourceModel\Inquiry::class);
    }
}
