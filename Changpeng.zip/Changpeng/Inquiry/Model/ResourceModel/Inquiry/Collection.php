<?php
/**
 * Class Collection
 *
 * PHP version 7 & 8
 *
 * @category Changpeng
 * @package  Changpeng_Inquiry
 * @author   Changpeng <magento@changpeng.com>
 * @license  https://hncpsm.com  Open Software License (OSL 3.0)
 * @link     https://hncpsm.com */
namespace Changpeng\Inquiry\Model\ResourceModel\Inquiry;


class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = 'entity_id';
    /**
     * @var string
     */
    protected $_eventPrefix = 'changpeng_product_inquiry_post_collection';
    /**
     * @var string
     */
    protected $_eventObject = 'product_inquiry_collection';

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(
            \Changpeng\Inquiry\Model\Inquiry::class,
            \Changpeng\Inquiry\Model\ResourceModel\Inquiry::class
        );
    }
}
