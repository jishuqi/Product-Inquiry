<?php
/**
 * Class Inquiry
 *
 * PHP version 7 & 8
 *
 * @category Changpeng
 * @package  Changpeng_Inquiry
 * @author   Changpeng <magento@changpeng.com>
 * @license  https://hncpsm.com  Open Software License (OSL 3.0)
 * @link     https://hncpsm.com */
namespace Changpeng\Inquiry\Model\ResourceModel;


class Inquiry extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Define Maintable and primarykey
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('changpeng_product_inquiry', 'entity_id');
    }
}
